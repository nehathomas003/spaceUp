const express = require("express")
const path = require("path")
const app = express()
// const hbs = require("hbs")
const LogInCollection = require("./mongodb")
const carParkingCollection= require("./mongodb1")
const carpoolRequestCollection= require("./mongodb2")
const carpoolAddinCollection = require("./mongodb3")
const port = process.env.PORT || 3000
app.use(express.json())
app.use(express.static('images'))
app.use(express.static('templates'))




const bodyParser = require('body-parser');



// Parse URL-encoded bodies (as sent by HTML forms)
app.use(bodyParser.urlencoded({ extended: true }));

// Parse JSON bodies (as sent by API clients)
app.use(bodyParser.json());


app.use(express.urlencoded({ extended: false }))

const tempelatePath = path.join(__dirname, '../templates')
const publicPath = path.join(__dirname, '../public')
console.log(publicPath);

app.set('view engine', 'hbs')
app.set('views', tempelatePath)
app.use(express.static(publicPath))
app.use(express.static(__dirname + '/images'));

// hbs.registerPartials(partialPath)

const {engine} = require('express-handlebars')
app.engine('.hbs',engine({
    extname:'.hbs',
    defaultLayout:false,
    layoutsDir:'templates'
}))

app.set('view engine','hbs')

app.get('/signup', (req, res) => {
    res.render('signup')
})
app.get('/', (req, res) => {
    res.render('entrypage')
})

app.get('/login', (req, res) => {
    res.render('login')
})






app.post('/signup', async (req, res) => {
   
    
    // const data = new LogInCollection({
    //     name: req.body.name,
    //     password: req.body.password
    // })
    // await data.save()

    const data = {
        firstname: req.body.firstname,
        lastname: req.body.lastname, 
        uid: req.body.uid, 
        reg:req.body.reg,
        phone: req.body.phone,
        branch: req.body.branch,
        gradyear: req.body.gradyear, 
        password: req.body.password
    }

    const checking = await LogInCollection.findOne({ uid: req.body.uid })

    try {
        if (checking) {
           
            res.send("User details already exist")
        } else {
           
            await LogInCollection.create([data])
        }
    } catch (err) {
        
        res.send("Error: " + err)
    }
   
    res.status(201).render("login")
})


app.post('/login', async (req, res) => {

    try {
        const check = await LogInCollection.findOne({ uid: req.body.uid })

        if (check.password === req.body.password) {
                res.status(201).render("home", {
                    username: req.body.uid
                })
        }

        else {
            res.send("incorrect password")
        }

    } 
    catch (e) {

        res.send("wrong details")
        res.send("error is: " + e)
    }

    const username=req.body.uid;

    app.get('/findAspot', (req, res) => {
        res.status(201).render("findAspot", {
            username: username
        }) 
    })
    app.get('/contactDriver', (req, res) => {
        res.status(201).render("contactDriver", {
            username: username
        }) 
    })


    app.get('/carpool', async (req, res) => {
        try {
            const checks = await carpoolRequestCollection.find({}).lean();
            const checks2 = await carpoolAddinCollection.find({}).lean();
            res.status(201).render("carpool", { username: username, checks:checks,checks2:checks2 });
        } catch (e) {
            res.status(500).send("Error: " + e);
        }
    })
    
})




app.post('/contactDriver', async (req, res) => {
    try {

      
        const checks = await LogInCollection.findOne({ $or: [{ reg: req.body.val }, { uid: req.body.val }] });

        if (checks) {
            const { firstname, lastname, branch, gradyear, phone } = checks;

            res.status(201).render("contactDriver", {
                firstname: firstname,
                lastname: lastname,
                phone: phone,
                branch: branch,
                gradyear: gradyear,
            });

        } else {
            res.send("Driver not found");
        }
    } catch (e) {
        res.send("Wrong details. Error: " + e);
    }
});





app.post('/findAspot', async (req, res) => {


   
    const data = {
        spot:req.body.spot,
        user:req.body.user
    }

    await carParkingCollection.create([data])
       
})

app.post('/carpoolRequest', async (req, res) => {
   
    const data = {
        user:req.body.user,
        stop:req.body.stop,
        time:req.body.time
    }

    await carpoolRequestCollection.create([data])
    res.redirect('/carpool');

       
})

app.post('/contactD', async (req, res) => {
    const username=req.body.useruser;
    console.log("print: "+ username)
    const val=req.body.uid;
    res.status(201).render("contactDriver2", { username: username, val:val });
});


app.post('/carpoolAddin', async (req, res) => {

        
        const data = {
            useruseruser:req.body.useruseruser,
            availability:req.body.availability,
            destinationStart:req.body.destinationStart,
            timing:req.body.timing,
            specificStops:req.body.specificStops
        }
    
        await carpoolAddinCollection.create([data])
        res.redirect('/carpool');

      
})




app.listen(port, () => {
    console.log('port connected');
})